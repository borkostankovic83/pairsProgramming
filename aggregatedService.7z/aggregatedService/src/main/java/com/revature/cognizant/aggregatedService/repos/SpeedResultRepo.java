package com.revature.cognizant.aggregatedService.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revature.cognizant.model.SpeedResult;

public interface SpeedResultRepo extends JpaRepository<SpeedResult, Integer> {

}
