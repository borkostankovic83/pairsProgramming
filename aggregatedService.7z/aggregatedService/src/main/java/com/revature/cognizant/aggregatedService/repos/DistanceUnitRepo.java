package com.revature.cognizant.aggregatedService.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revature.cognizant.model.DistanceUnit;

public interface DistanceUnitRepo extends JpaRepository<DistanceUnit, Integer>{

}
