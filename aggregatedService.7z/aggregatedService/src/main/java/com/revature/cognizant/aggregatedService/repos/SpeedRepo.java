package com.revature.cognizant.aggregatedService.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revature.cognizant.model.Speed;

public interface SpeedRepo extends JpaRepository<Speed, Integer>{

}
