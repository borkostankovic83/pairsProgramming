package com.revature.cognizant.aggregatedService;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.cognizant.aggregatedService.conroller.AggregatedController;
import com.revature.cognizant.model.Distance;
import com.revature.cognizant.model.DistanceUnit;
import com.revature.cognizant.model.Speed;
import com.revature.cognizant.model.SpeedResult;

@SpringBootTest
class AggregatedServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void postRequestBody() {
		AggregatedController ac = new AggregatedController();
		Distance dist = new Distance();
		dist.setUnit(200.0);
		dist.setDistanceUnit(DistanceUnit.Feet);
		Speed spd = new Speed();
		spd.setDistance(dist);
		Duration dur;
		dur.plusMinutes(45.0);
		spd.setDuration();
		SpeedResult sr = new SpeedResult(0, "Drop tennis ball", );
		sr.
		ObjectMapper om = new ObjectMapper();
		String test = om.writeValueAsString(value);
		String result = ac.postExperiment(test);
	}
}
